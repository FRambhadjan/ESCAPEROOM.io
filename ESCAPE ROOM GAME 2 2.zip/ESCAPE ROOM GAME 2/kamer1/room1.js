function DoorClosed() {
    alert("De deur is dicht en als je het probeert open te maken wordt de deur teruggeduwd.")
}