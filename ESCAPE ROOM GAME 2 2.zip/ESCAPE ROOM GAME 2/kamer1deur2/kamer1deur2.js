function locker() {
    const locker = prompt('Wat is de 3 cijferige code?')

    if (locker == 420) {
        alert('De locker is open'); window.location.href = "http://127.0.0.1:5500/kamer1deur2b/kamer1deur2.html";

    } else {
        alert("fout");
    }
}